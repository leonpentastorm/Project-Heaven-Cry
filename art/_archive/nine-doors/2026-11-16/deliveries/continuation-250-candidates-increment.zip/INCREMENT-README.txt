This incremental archive adds 75 candidates to the preserved 175-candidate baseline. New total: 250. It is not a complete 250-image library.
